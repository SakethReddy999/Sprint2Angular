import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService,  Ticket } from '../myservice.service';

@Component({
  selector: 'app-ticket',
  templateUrl: './ticket.component.html',
  styleUrls: ['./ticket.component.css']
})
export class TicketComponent implements OnInit {
  message:String;
  
  constructor(private myservice: MyserviceService,private router: Router) { }

  ngOnInit(): void {
  }
  onSubmit(addticket:Ticket):any{
    console.log(addticket);
     this.myservice.addticket(addticket).subscribe(data => {
      this.message=data});
  }

}
