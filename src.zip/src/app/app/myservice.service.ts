import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  generateTicket: Ticket;
  constructor(private httpService: HttpClient) { }
  public getTicket() {
    console.log("ins service get ticket");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Ticket>("http://localhost:8345/Ticket/GetAllTicket");
  }

  public addticket(addticket: Ticket) {
    console.log("ins service add");
    console.log(addticket);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:8345/ticket/Ticketgeneration", addticket,  { headers, responseType: 'text'});
  }
  
  }
export class Ticket {
  ticketid: number;
  bookingref:  number;
  screenName: string;
  noofseats: number;
  seatname: number;
  ticketstatus: Boolean;

 
}
